import Live 
from A_FCB1010 import A_FCB1010 

def create_instance(c_instance):
    ' Creates and returns the APC20 script '
    return A_FCB1010(c_instance)
    

