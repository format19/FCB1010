####################################################################################################################
#~~~~~~~~MEC All working FCB1010 Midi CH 16 Banks 00-09 as per jpg's in folder 31-12-20 12:57 ~~~~~~~~~~~
# Dimension of the surfaces
# The clip session matrix definition must be matrix MATRIX_DEPTH * TRACK_NUMBER
# All other vectors referring to tracks must be TRACK_NUMBER long.
MATRIX_DEPTH = 5 #number of scenes in the box
TRACK_NUMBER = 8 #number of tracks for Mixer mapping
NUMBER_BUTTONS = 42 #number of buttons in BUTTON_VECTOR
NUMBER_SLIDERS = 4 #number of sliders in SLIDER_VECTOR
BANKS_NUMBER = 8 #number of parameter banks
PARAMS_NUMBER = 8 #number of parameters per bank
PAD_X_NUMBER = -1 #number of pad columns
PAD_Y_NUMBER = -1 #number of pad rows

###########################################################
# Combination Mode offsets for more identical surfaces
TRACK_OFFSET = -1 #offset from the left of linked session origin; set to -1 for auto-joining of multiple instances
SCENE_OFFSET = -1 #offset from the top of linked session origin (no auto-join)

###########################################################
# Tempo Range
TEMPO_TOP = 199.0 # Upper limit of tempo control in BPM (max is 999)
TEMPO_BOTTOM = 50.0 # Lower limit of tempo control in BPM (min is 0)

###########################################################
# Individual Scene Buttons 
# Note: must be at least MATRIX_DEPTH long
# Type 0 == MIDI notes, Type 1 == MIDI CC
# CH must be in the range 0 to 15 (corresponding to MIDI channels 1 to 16)

SCENELAUNCH = (0, #48, #Scene 1
              1, #49, #Scene 2
              2, #50, #Scene 3
              3, #51, #Scene 4
              4, #Scene 5
              -1, #Scene 6
              -1, #Scene 7
              -1, #Scene 8
              -1, #Scene 9
              -1, #Scene 10
               )

SCENELAUNCH_TYPE = (0, #Scene 1
               0, #Scene 2
               0, #Scene 3
               0, #Scene 4
               0, #Scene 5
               0, #Scene 6
               0, #Scene 7
               0, #Scene 8
               0, #Scene 9
               0, #Scene 10
               )

SCENELAUNCH_CH = (15, #Scene 1
               15, #Scene 2
               15, #Scene 3
               15, #Scene 4
               15, #Scene 5
               15, #Scene 6
               15, #Scene 7
               15, #Scene 8
               15, #Scene 9
               15, #Scene 10
               )

###########################################################
# Clip Matrix
# Note: must be at least have MATRIX_DEPTH * TRACK_NUMBER dimensions 
#  - istage -
# Track no.:     1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25  26  27  28  29  30  31  32
CLIPNOTEMAP = ((10, 20, 30, 40, 50, 60, 70, 80, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 1
               (11, 21, 31, 41, 51, 61, 71, 81, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 2
               (12, 22, 32, 42, 52, 62, 72, 82, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 3
               (13, 23, 33, 43, 53, 63, 73, 83, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 4
               (14, 24, 34, 44, 54, 64, 74, 84, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 5
               (-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 6
               (-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 7
               (-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 8
               (-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 9
               (-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1), # 10
               )

CLIPNOTEMAP_TYPE = ((0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 1
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 2
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 3
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 4
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 5
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 6
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 7
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 8
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 9
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 10
               )

CLIPNOTEMAP_CH = ((15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 1
               (15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 2
               (15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 3
               (15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 4
               (15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 5
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 6
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 7
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 8
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 9
               (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0), # 10
               )

###########################################################
# Single Buttons
BUTTON_VECTOR = (7, #Global play 				        	[0]
                8, #Global stop 					          [1]
                9, #Global record 				        	[2]
                -1, #Tap tempo 					          	[3]
                -1, #Tempo Nudge Up 			        	[4]
                -1, #Tempo Nudge Down 			      	[5]
                -1, #Undo 							            [6]
                -1, #Redo 							            [7]
                -1, #Loop 							            [8]
                -1, #Punch in	 					            [9]
                -1, #Punch out 						          [10]
                -1, #Overdub on/off 			        	[11]
                -1, #Metronome on/off 		      		[12]
                -1, #Record quantization on/off   	[13]
                -1, #42, #Detail view switch 		    [14]
                -1, #43, #Clip/Track view switch 	  [15]
                99, #Device Lock (lock "blue hand")	[16]
                94, #Device on/off 					        [17]
                92, #Device nav left 				        [18]
                93, #Device nav right 				      [19]
                -1, #Device bank nav left 			    [20]
                -1, #Device bank nav right 			    [21]
                -1, #Seek forward 					        [22]
                -1, #Seek rewind 					          [23]
                95, #Session left 			   - istage	[24]
                96, #Session right 			   - istage	[25]
                -1, #Session up 				   - istage	[26]
                -1, #Session down 			   - istage	[27]
                98, #Session Zoom up 		   - istage	[28]
                97, #Session Zoom down 	   - istage [29]
                -1, #Session Zoom left 	   - istage [30]
                -1, #Session Zoom right    - istage [31]
                90, #38, #Track left 		   - psr	  [32]
                91, #39, #Track right 	   - psr    [33]
                -1, #37, #Scene down 		   - psr	  [34]
                -1, #36, #Scene up 			   - psr    [35]
                -1, #Selected scene launch - istage [36]
                -1, #Selected clip launch  - istage [37]
                5, #Stop all clips        - istage [38]
                6, #Master track select		      	[39]
                -1, #Session bank left 			      	[40]
                -1, #Session bank right			        [41]
                )

BUTTON_VECTOR_TYPE = (0, #Global play 			      	[0] Type
                 0, #Global stop 					          [1] Type
                 0, #Global record 				        	[2] Type
                 0, #Tap tempo 					          	[3] Type
                 0, #Tempo Nudge Up 			        	[4] Type
                 0, #Tempo Nudge Down 			      	[5] Type
                 0, #Undo 							            [6] Type
                 0, #Redo 							            [7] Type
                 0, #Loop 							            [8] Type
                 0, #Punch in	 					            [9] Type
                 0, #Punch out 						          [10] Type
                 0, #Overdub on/off 			        	[11] Type
                 0, #Metronome on/off 		      		[12] Type
                 0, #Record quantization on/off   	[13] Type
                 0, #Detail view switch 		      	[14] Type
                 0, #Clip/Track view switch 	     	[15] Type
                 0, #Device Lock (lock "blue hand")	[16] Type
                 0, #Device on/off 					        [17] Type
                 0, #Device nav left 				        [18] Type
                 0, #Device nav right 				      [19] Type
                 0, #Device bank nav left 			    [20] Type
                 0, #Device bank nav right 			    [21] Type
                 0, #Seek forward 					        [22] Type
                 0, #Seek rewind 					          [23] Type
                 0, #Session left 					        [24] Type
                 0, #Session right 					        [25] Type
                 0, #Session up 					          [26] Type
                 0, #Session down 					        [27] Type
                 0, #Session Zoom up 				        [28] Type
                 0, #Session Zoom down 				      [29] Type
                 0, #Session Zoom left 				      [30] Type
                 0, #Session Zoom right 			      [31] Type
                 0, #Track left 					          [32] Type
                 0, #Track right 					          [33] Type
                 0, #Scene down 					          [34] Type
                 0, #Scene up 						          [35] Type
                 0, #Selected scene launch 			    [36] Type
                 0, #Selected clip launch 			    [37] Type
                 0, #Stop all clips 				        [38] Type
                 0, #Master track select		      	[39] Type
                 0, #Session bank left 			      	[40] Type
                 0, #Session bank right			        [41] Type                 
                )

BUTTON_VECTOR_CH = (15, #Global play 				        [0] Channel
                 15, #Global stop 					        [1] Channel
                 15, #Global record 				        [2] Channel
                 15, #Tap tempo 					          [3] Channel
                 15, #Tempo Nudge Up 			        	[4] Channel
                 15, #Tempo Nudge Down 			      	[5] Channel
                 15, #Undo 							            [6] Channel
                 15, #Redo 							            [7] Channel
                 15, #Loop 							            [8] Channel
                 15, #Punch in	 					          [9] Channel
                 15, #Punch out 						        [10] Channel
                 15, #Overdub on/off 			        	[11] Channel
                 15, #Metronome on/off 		      		[12] Channel
                 15, #Record quantization on/off   	[13] Channel
                 15, #Detail view switch 		      	[14] Channel
                 15, #Clip/Track view switch 	     	[15] Channel
                 15, #Device Lock (lock "blue hand")[16] Channel
                 15, #Device on/off 					      [17] Channel
                 15, #Device nav left 				      [18] Channel
                 15, #Device nav right 				      [19] Channel
                 15, #Device bank nav left 			    [20] Channel
                 15, #Device bank nav right 			  [21] Channel
                 15, #Seek forward 					        [22] Channel
                 15, #Seek rewind 					        [23] Channel
                  15, #Session left 					        [24] Channel
                  15, #Session right 					      [25] Channel
                  15, #Session up 					          [26] Channel
                  15, #Session down 					        [27] Channel
                  15, #Session Zoom up    - istage   [28] Channel
                  15, #Session Zoom down  - istage   [29] Channel
                  15, #Session Zoom left  - istage	  [30] Channel
                  15, #Session Zoom right - istage   [31] Channel
                 15, #Track left 				 - psr  	  [32] Channel
                 15, #Track right 			 - psr  	  [33] Channel
                 15, #Scene down 				 - psr  	  [34] Channel
                 15, #Scene up 					 - psr  	  [35] Channel
                  15, #Selected scene launch 			  [36] Channel
                  15, #Selected clip launch 			    [37] Channel
                  15, #Stop all clips 		 - istage	  [38] Channel
                 15, #Master track select		      	[39] Channel
                  15, #Session bank left 			      [40] Channel
                  15, #Session bank right			      [41] Channel                  
                )

###########################################################
# Single Sliders

SLIDER_VECTOR = (01, #Master track volume	    -mtb  [0]
                00, #Cue level control			      	[1]
                -1, #Crossfader control			      	[2]
                -1, #Tempo control	          -   	[3]
                )

SLIDER_VECTOR_TYPE = (1, #Master track volume	    	[0] Type
                 1, #Cue level control			      	[1] Type
                 1, #Crossfader control			      	[2] Type
                 1, #Tempo control				        	[3] Type
                )

SLIDER_VECTOR_CH = (15, #Master track volume		-mtb  [0] Channel
                 15, #Cue level control			      	[1] Channel
                 15, #Crossfader control			      	[2] Channel
                 15, #Tempo control	          -   	[3] Channel
                )

###########################################################
# Track Stop Buttons
# Note: Must be at least TRACK_NUMBER long
TRACKSTOP = (15, #Track 1 Clip Stop
             25, #Track 2 
             35, #Track 3 
             45, #Track 4 
             55, #Track 5 
             65, #Track 6 
             75, #Track 7 
             85, #Track 8 
             -1, #Track 9
             -1, #Track 10
             -1, #Track 11
             -1, #Track 12
             -1, #Track 13
             -1, #Track 14
             -1, #Track 15
             -1, #Track 16
             -1, #Track 17
             -1, #Track 18
             -1, #Track 19
             -1, #Track 20
             -1, #Track 21
             -1, #Track 22
             -1, #Track 23
             -1, #Track 24
             -1, #Track 25
             -1, #Track 26
             -1, #Track 27
             -1, #Track 28
             -1, #Track 29
             -1, #Track 30
             -1, #Track 31
             -1, #Track 32
             )

TRACKSTOP_TYPE = (0, # Type for Track 1
             0, # Type for Track 2
             0, # Type for Track 3
             0, # Type for Track 4
             0, # Type for Track 5
             0, # Type for Track 6
             0, # Type for Track 7
             0, # Type for Track 8
             0, # Type for Track 9
             0, # Type for Track 10
             0, # Type for Track 11
             0, # Type for Track 12
             0, # Type for Track 13
             0, # Type for Track 14
             0, # Type for Track 15
             0, # Type for Track 16
             0, # Type for Track 17
             0, # Type for Track 18
             0, # Type for Track 19
             0, # Type for Track 20
             0, # Type for Track 21
             0, # Type for Track 22
             0, # Type for Track 23
             0, # Type for Track 24
             0, # Type for Track 25
             0, # Type for Track 26
             0, # Type for Track 27
             0, # Type for Track 28
             0, # Type for Track 29
             0, # Type for Track 30
             0, # Type for Track 31
             0, # Type for Track 32
             )

TRACKSTOP_CH = (15, # Channel for Track 1
             15, # Channel for Track 2
             15, # Channel for Track 3
             15, # Channel for Track 4
             15, # Channel for Track 5
             15, # Channel for Track 6
             15, # Channel for Track 7
             15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Select Buttons
# Note: Must be at least TRACK_NUMBER long
TRACKSEL = (16, #Track 1 Select             - psr
            26, #Track 2            - psr
            36, #Track 3            - psr
            46, #Track 4            - psr
            56, #Track 5            - psr
            66, #Track 6            - psr
            76, #Track 7            - psr
            86, #Track 8            - psr
            -1, #Track 9
            -1, #Track 10
            -1, #Track 11
            -1, #Track 12
            -1, #Track 13
            -1, #Track 14
            -1, #Track 15
            -1, #Track 16
            -1, #Track 17
            -1, #Track 18
            -1, #Track 19
            -1, #Track 20
            -1, #Track 21
            -1, #Track 22
            -1, #Track 23
            -1, #Track 24
            -1, #Track 25
            -1, #Track 26
            -1, #Track 27
            -1, #Track 28
            -1, #Track 29
            -1, #Track 30
            -1, #Track 31
            -1, #Track 32
			 )

TRACKSEL_TYPE = (0, # Type for Track 1
             0, # Type for Track 2
             0, # Type for Track 3
             0, # Type for Track 4
             0, # Type for Track 5
             0, # Type for Track 6
             0, # Type for Track 7
             0, # Type for Track 8
             0, # Type for Track 9
             0, # Type for Track 10
             0, # Type for Track 11
             0, # Type for Track 12
             0, # Type for Track 13
             0, # Type for Track 14
             0, # Type for Track 15
             0, # Type for Track 16
             0, # Type for Track 17
             0, # Type for Track 18
             0, # Type for Track 19
             0, # Type for Track 20
             0, # Type for Track 21
             0, # Type for Track 22
             0, # Type for Track 23
             0, # Type for Track 24
             0, # Type for Track 25
             0, # Type for Track 26
             0, # Type for Track 27
             0, # Type for Track 28
             0, # Type for Track 29
             0, # Type for Track 30
             0, # Type for Track 31
             0, # Type for Track 32
             )

TRACKSEL_CH = (15, # Channel for Track 1
             15, # Channel for Track 2
             15, # Channel for Track 3
             15, # Channel for Track 4
             15, # Channel for Track 5
             15, # Channel for Track 6
             15, # Channel for Track 7
             15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Mute Buttons
# Note: Must be at least TRACK_NUMBER long
TRACKMUTE = (17, #Track 1 On/Off            - mtb
             27, #Track 2            - mtb  
             37, #Track 3            - mtb 
             47, #Track 4            - mtb 
             57, #Track 5            - mtb 
             67, #Track 6            - mtb 
             77, #Track 7            - mtb 
             87, #Track 8            - mtb
             -1, #Track 9
             -1, #Track 10
             -1, #Track 11
             -1, #Track 12
             -1, #Track 13
             -1, #Track 14
             -1, #Track 15
             -1, #Track 16
             -1, #Track 17
             -1, #Track 18
             -1, #Track 19
             -1, #Track 20
             -1, #Track 21
             -1, #Track 22
             -1, #Track 23
             -1, #Track 24
             -1, #Track 25
             -1, #Track 26
             -1, #Track 27
             -1, #Track 28
             -1, #Track 29
             -1, #Track 30
             -1, #Track 31
             -1, #Track 32
             )

TRACKMUTE_TYPE = (0, # Type for Track 1
             0, # Type for Track 2
             0, # Type for Track 3
             0, # Type for Track 4
             0, # Type for Track 5
             0, # Type for Track 6
             0, # Type for Track 7
             0, # Type for Track 8
             0, # Type for Track 9
             0, # Type for Track 10
             0, # Type for Track 11
             0, # Type for Track 12
             0, # Type for Track 13
             0, # Type for Track 14
             0, # Type for Track 15
             0, # Type for Track 16
             0, # Type for Track 17
             0, # Type for Track 18
             0, # Type for Track 19
             0, # Type for Track 20
             0, # Type for Track 21
             0, # Type for Track 22
             0, # Type for Track 23
             0, # Type for Track 24
             0, # Type for Track 25
             0, # Type for Track 26
             0, # Type for Track 27
             0, # Type for Track 28
             0, # Type for Track 29
             0, # Type for Track 30
             0, # Type for Track 31
             0, # Type for Track 32
             )

TRACKMUTE_CH = (15, # Channel for Track 1
              15, # Channel for Track 2
              15, # Channel for Track 3
              15, # Channel for Track 4
              15, # Channel for Track 5
              15, # Channel for Track 6
              15, # Channel for Track 7
              15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Solo Buttons
# Note: Must be at least TRACK_NUMBER long
TRACKSOLO = (18, #Track 1 Solo              - mtb
             28, #Track 2            - mtb
             38, #Track 3            - mtb
             48, #Track 4            - mtb
             58, #Track 5            - mtb
             68, #Track 6            - mtb
             78, #Track 7            - mtb
             88, #Track 8            - mtb
             -1, #Track 9
             -1, #Track 10
             -1, #Track 11
             -1, #Track 12
             -1, #Track 13
             -1, #Track 14
             -1, #Track 15
             -1, #Track 16
             -1, #Track 17
             -1, #Track 18
             -1, #Track 19
             -1, #Track 20
             -1, #Track 21
             -1, #Track 22
             -1, #Track 23
             -1, #Track 24
             -1, #Track 25
             -1, #Track 26
             -1, #Track 27
             -1, #Track 28
             -1, #Track 29
             -1, #Track 30
             -1, #Track 31
             -1, #Track 32
             )

TRACKSOLO_TYPE = (0, # Type for Track 1
             0, # Type for Track 2
             0, # Type for Track 3
             0, # Type for Track 4
             0, # Type for Track 5
             0, # Type for Track 6
             0, # Type for Track 7
             0, # Type for Track 8
             0, # Type for Track 9
             0, # Type for Track 10
             0, # Type for Track 11
             0, # Type for Track 12
             0, # Type for Track 13
             0, # Type for Track 14
             0, # Type for Track 15
             0, # Type for Track 16
             0, # Type for Track 17
             0, # Type for Track 18
             0, # Type for Track 19
             0, # Type for Track 20
             0, # Type for Track 21
             0, # Type for Track 22
             0, # Type for Track 23
             0, # Type for Track 24
             0, # Type for Track 25
             0, # Type for Track 26
             0, # Type for Track 27
             0, # Type for Track 28
             0, # Type for Track 29
             0, # Type for Track 30
             0, # Type for Track 31
             0, # Type for Track 32
             )

TRACKSOLO_CH = (15, # Channel for Track 1
             15, # Channel for Track 2
             15, # Channel for Track 3
             15, # Channel for Track 4
             15, # Channel for Track 5
             15, # Channel for Track 6
             15, # Channel for Track 7
             15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Record/Arm Buttons
# Note: Must be at least TRACK_NUMBER long
TRACKREC = (19, #Track 1 Record             - mtb
            29, #Track 2            - mtb
            39, #Track 3            - mtb
            49, #Track 4            - mtb
            59, #Track 5            - mtb
            69, #Track 6            - mtb
            79, #Track 7            - mtb
            89, #Track 8            - mtb
            -1, #Track 9
            -1, #Track 10
            -1, #Track 11
            -1, #Track 12
            -1, #Track 13
            -1, #Track 14
            -1, #Track 15
            -1, #Track 16
            -1, #Track 17
            -1, #Track 18
            -1, #Track 19
            -1, #Track 20
            -1, #Track 21
            -1, #Track 22
            -1, #Track 23
            -1, #Track 24
            -1, #Track 25
            -1, #Track 26
            -1, #Track 27
            -1, #Track 28
            -1, #Track 29
            -1, #Track 30
            -1, #Track 31
            -1, #Track 32
            )

TRACKREC_TYPE = (0, # Type for Track 1
             0, # Type for Track 2
             0, # Type for Track 3
             0, # Type for Track 4
             0, # Type for Track 5
             0, # Type for Track 6
             0, # Type for Track 7
             0, # Type for Track 8
             0, # Type for Track 9
             0, # Type for Track 10
             0, # Type for Track 11
             0, # Type for Track 12
             0, # Type for Track 13
             0, # Type for Track 14
             0, # Type for Track 15
             0, # Type for Track 16
             0, # Type for Track 17
             0, # Type for Track 18
             0, # Type for Track 19
             0, # Type for Track 20
             0, # Type for Track 21
             0, # Type for Track 22
             0, # Type for Track 23
             0, # Type for Track 24
             0, # Type for Track 25
             0, # Type for Track 26
             0, # Type for Track 27
             0, # Type for Track 28
             0, # Type for Track 29
             0, # Type for Track 30
             0, # Type for Track 31
             0, # Type for Track 32
             )

TRACKREC_CH = (15, # Channel for Track 1
              15, # Channel for Track 2
              15, # Channel for Track 3
              15, # Channel for Track 4
              15, # Channel for Track 5
              15, # Channel for Track 6
              15, # Channel for Track 7
              15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Volume Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKVOL = (03, #Track 1 Volume             - mtb
            05, #Track 2            - mtb
            07, #Track 3            - mtb
            9, #Track 4            - mtb
            11, #Track 5            - mtb
            13, #Track 6            - mtb
            15, #Track 7            - mtb
            17, #Track 8            - mtb
            -1, #Track 9
            -1, #Track 10
            -1, #Track 11
            -1, #Track 12
            -1, #Track 13
            -1, #Track 14
            -1, #Track 15
            -1, #Track 16
            -1, #Track 17
            -1, #Track 18
            -1, #Track 19
            -1, #Track 20
            -1, #Track 21
            -1, #Track 22
            -1, #Track 23
            -1, #Track 24
            -1, #Track 25
            -1, #Track 26
            -1, #Track 27
            -1, #Track 28
            -1, #Track 29
            -1, #Track 30
            -1, #Track 31
            -1, #Track 32
            )

TRACKVOL_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKVOL_CH = (15, # Channel for Track 1
             15, # Channel for Track 2
             15, # Channel for Track 3
             15, # Channel for Track 4
             15, # Channel for Track 5
             15, # Channel for Track 6
             15, # Channel for Track 7
             15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Pan Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKPAN = (-1, #Track 1 Pan                - mtb 
            -1, #Track 2            - 
            -1, #Track 3            - 
            -1, #Track 4            - 
            -1, #Track 5            - 
            -1, #Track 6            - 
            -1, #Track 7            - 
            -1, #Track 8            - 
            -1, #Track 9
            -1, #Track 10
            -1, #Track 11
            -1, #Track 12
            -1, #Track 13
            -1, #Track 14
            -1, #Track 15
            -1, #Track 16
            -1, #Track 17
            -1, #Track 18
            -1, #Track 19
            -1, #Track 20
            -1, #Track 21
            -1, #Track 22
            -1, #Track 23
            -1, #Track 24
            -1, #Track 25
            -1, #Track 26
            -1, #Track 27
            -1, #Track 28
            -1, #Track 29
            -1, #Track 30
            -1, #Track 31
            -1, #Track 32
            )

TRACKPAN_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKPAN_CH = (8, # Channel for Track 1
             8, # Channel for Track 2
             8, # Channel for Track 3
             8, # Channel for Track 4
             8, # Channel for Track 5
             8, # Channel for Track 6
             8, # Channel for Track 7
             8, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )

###########################################################
# Track Send A Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDA = (02, #Track 1 Send A
              04, #Track 2
              06, #Track 3
              8, #Track 4
              10, #Track 5
              12, #Track 6
              14, #Track 7
              16, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDA_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDA_CH = (15, # Channel for Track 1
             15, # Channel for Track 2
             15, # Channel for Track 3
             15, # Channel for Track 4
             15, # Channel for Track 5
             15, # Channel for Track 6
             15, # Channel for Track 7
             15, # Channel for Track 8
             15, # Channel for Track 9
             15, # Channel for Track 10
             15, # Channel for Track 11
             15, # Channel for Track 12
             15, # Channel for Track 13
             15, # Channel for Track 14
             15, # Channel for Track 15
             15, # Channel for Track 16
             15, # Channel for Track 17
             15, # Channel for Track 18
             15, # Channel for Track 19
             15, # Channel for Track 20
             15, # Channel for Track 21
             15, # Channel for Track 22
             15, # Channel for Track 23
             15, # Channel for Track 24
             15, # Channel for Track 25
             15, # Channel for Track 26
             15, # Channel for Track 27
             15, # Channel for Track 28
             15, # Channel for Track 29
             15, # Channel for Track 30
             15, # Channel for Track 31
             15, # Channel for Track 32
             )

###########################################################
# Track Send B Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDB = (-1, #Track 1 Send B
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDB_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDB_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )

###########################################################
# Track Send C Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDC = (-1, #Track 1 Send C
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDC_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDC_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )

###########################################################
# Track Send D Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDD = (-1, #Track 1 Send D
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDD_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDD_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )
###########################################################
# Track Send E Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDE = (-1, #Track 1 Send E
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDE_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDE_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )
###########################################################
# Track Send F Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDF = (-1, #Track 1 Send F
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDF_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDF_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )
###########################################################
# Track Send G Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDG = (-1, #Track 1 Send G
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDG_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDG_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )
###########################################################
# Track Send H Sliders
# Note: Must be at least TRACK_NUMBER long
TRACKSENDH = (-1, #Track 1 Send H
              -1, #Track 2
              -1, #Track 3
              -1, #Track 4
              -1, #Track 5
              -1, #Track 6
              -1, #Track 7
              -1, #Track 8
              -1, #Track 9
              -1, #Track 10
              -1, #Track 11
              -1, #Track 12
              -1, #Track 13
              -1, #Track 14
              -1, #Track 15
              -1, #Track 16
              -1, #Track 17
              -1, #Track 18
              -1, #Track 19
              -1, #Track 20
              -1, #Track 21
              -1, #Track 22
              -1, #Track 23
              -1, #Track 24
              -1, #Track 25
              -1, #Track 26
              -1, #Track 27
              -1, #Track 28
              -1, #Track 29
              -1, #Track 30
              -1, #Track 31
              -1, #Track 32
              )

TRACKSENDH_TYPE = (1, # Type for Track 1
             1, # Type for Track 2
             1, # Type for Track 3
             1, # Type for Track 4
             1, # Type for Track 5
             1, # Type for Track 6
             1, # Type for Track 7
             1, # Type for Track 8
             1, # Type for Track 9
             1, # Type for Track 10
             1, # Type for Track 11
             1, # Type for Track 12
             1, # Type for Track 13
             1, # Type for Track 14
             1, # Type for Track 15
             1, # Type for Track 16
             1, # Type for Track 17
             1, # Type for Track 18
             1, # Type for Track 19
             1, # Type for Track 20
             1, # Type for Track 21
             1, # Type for Track 22
             1, # Type for Track 23
             1, # Type for Track 24
             1, # Type for Track 25
             1, # Type for Track 26
             1, # Type for Track 27
             1, # Type for Track 28
             1, # Type for Track 29
             1, # Type for Track 30
             1, # Type for Track 31
             1, # Type for Track 32
             )

TRACKSENDH_CH = (0, # Channel for Track 1
             0, # Channel for Track 2
             0, # Channel for Track 3
             0, # Channel for Track 4
             0, # Channel for Track 5
             0, # Channel for Track 6
             0, # Channel for Track 7
             0, # Channel for Track 8
             0, # Channel for Track 9
             0, # Channel for Track 10
             0, # Channel for Track 11
             0, # Channel for Track 12
             0, # Channel for Track 13
             0, # Channel for Track 14
             0, # Channel for Track 15
             0, # Channel for Track 16
             0, # Channel for Track 17
             0, # Channel for Track 18
             0, # Channel for Track 19
             0, # Channel for Track 20
             0, # Channel for Track 21
             0, # Channel for Track 22
             0, # Channel for Track 23
             0, # Channel for Track 24
             0, # Channel for Track 25
             0, # Channel for Track 26
             0, # Channel for Track 27
             0, # Channel for Track 28
             0, # Channel for Track 29
             0, # Channel for Track 30
             0, # Channel for Track 31
             0, # Channel for Track 32
             )

###########################################################
# Device Bank
# Note: All 8 banks must be assigned to positive values in order for bank selection to work
DEVICEBANK = (-1, #Bank 1                   - mtb
              -1, #Bank 2
              -1, #Bank 3
              -1, #Bank 4
              -1, #Bank 5
              -1, #Bank 6
              -1, #Bank 7
              -1, #Bank 8
              )

DEVICEBANK_TYPE = (0, #Bank 1
              0, #Bank 2
              0, #Bank 3
              0, #Bank 4
              0, #Bank 5
              0, #Bank 6
              0, #Bank 7
              0, #Bank 8
              )

DEVICEBANK_CH = (15, #Bank 1
              15, #Bank 2
              15, #Bank 3
              15, #Bank 4
              15, #Bank 5
              15, #Bank 6
              15, #Bank 7
              15, #Bank 8
              )

###########################################################
# Parameter Control Sliders
# Note: All 8 params must be assigned to positive values in order for param control to work
PARAMCONTROL = (-1, #Param 1               - mtb
                -1, #Param 2            - mtb
                -1, #Param 3            - mtb
                -1, #Param 4            - mtb
                -1, #Param 5            - mtb
                -1, #Param 6            - mtb
                -1, #Param 7            - mtb
                -1, #Param 8            - mtb
                )

PARAMCONTROL_TYPE = (1, #Param 1
                1, #Param 2
                1, #Param 3
                1, #Param 4
                1, #Param 5
                1, #Param 6
                1, #Param 7
                1, #Param 8
                )

PARAMCONTROL_CH = (0, #Param 1
                0, #Param 2
                0, #Param 3
                0, #Param 4
                0, #Param 5
                0, #Param 6
                0, #Param 7
                0, #Param 8
                )

###########################################################
# Pad Translations for Drum Rack
DRUM_PADS = (#-1, -1, -1, -1,#52, 53, 54, 55, # MIDI note numbers for 4 x 4 Drum Rack
             #-1, -1, -1, -1,#48, 49, 50, 51, # Mapping will be disabled if any notes are set to -1
             #-1, -1, -1, -1,#44, 45, 46, 47, # Notes will be "swallowed" if already mapped elsewhere
             #-1, -1, -1, -1,#40, 41, 42, 43, #  - istage -
             -1, -1, -1, -1, #48, 49, 50, 51,#
             -1, -1, -1, -1, #44, 45, 46, 47,#
             -1, -1, -1, -1, #40, 41, 42, 43,#
             -1, -1, -1, -1, #36, 37, 38, 39,#
             #26, 25, 24, 23,#
             #22, 21, 20, 19,#
             #18, 17, 16, 15,#
             #14, 13, 12, 11,#
             )

# Channel 0 to 15 for Drum Rack notes (MIDI channels 1 to 16)
PADCHANNEL = 9